#!/bin/bash

AM_HOME=/app/Verilog/nexus-am
MIPS_CPU_DIR=/app/Verilog/mips_cpu

export AM_HOME=$AM_HOME

# Build the app
cd $AM_HOME"/tests/myAMapp"

# rm -rf ./build/, exclude the .S file
find ./build/ -type f ! -name '*.S' -exec rm -rf {} \;

make ARCH=mips32-npc

if [ $? -ne 0 ]; then
    echo "Build failed"
    exit 1
fi

cd $AM_HOME

# Copy the binary to the right place

cp ./tests/myAMapp/build/bug-mips32-npc.bin .


xxd -c 4 -e bug-mips32-npc.bin | cut -c 11-18 > bug.mem

mv bug.mem $MIPS_CPU_DIR"/test/bug"


cd $MIPS_CPU_DIR

./test/test_bug.sh

python3 ../utils/beautify_mem.py