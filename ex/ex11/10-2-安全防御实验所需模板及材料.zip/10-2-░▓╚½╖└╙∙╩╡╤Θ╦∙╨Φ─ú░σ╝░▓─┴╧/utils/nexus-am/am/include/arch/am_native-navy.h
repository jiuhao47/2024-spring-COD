#ifndef __ARCH_H__
#define __ARCH_H__

#include <unistd.h>
#include <sys/types.h>

#define false 0
#define true 1

struct _Context {
};

#endif
